package com.project.hotel_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
